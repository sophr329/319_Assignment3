
// import { useState, useEffect } from "react";
// import {Link, useNavigate } from 'react-router-dom';
// import React from "react";
// import axios from 'axios'

//  function DeleteProd (){

//     const [products, setProducts] = useState([{
//         id: '',
//         title: '',
//         price: '',
//         description: '',
//         category: '',
//         image: '',
//         rating: ''
//     }]);

//     const navigate = useNavigate();
      
//     useEffect(() => {
//         fetch("http:localhost:8082/getProducts")
//         .then((response) => response.json())
//         .then((data) => {
//         setProducts(data);
//         console.log("Load initial Catalog of Products in DELETE :", data);
//         });
//     }, []);

    
// const deleteOneProduct = (id) => {
//     console.log("Product to delete :", id);
//     fetch("http://localhost:8082/getProducts/" + id, {
//     method: "DELETE",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify({"id":id}),
//     })
//     .then(response => {
//     if (response.status != 200){
//     return response.json()
//     .then(errData =>{
//     throw new Error(`POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`);
//     })
//     }
//     return response.json();})
//     .then((data) => {
//     console.log("Delete a product completed : ", id);
//     console.log(data);
//     // reload products from the local products array
//     const newProducts = products.filter(product => product.id !== id);
//     setProducts(newProducts);
//     setIndex(0);
//     // show alert
//     if (data) {
//     const key = Object.keys(data);
//     const value = Object.values(data);
//     alert(key+value);
//     }
//     })
//     .catch(error => {
//     console.error('Error adding item:', error);
//     alert('Error adding robot:'+error.message); // Display alert if there's an error
//     });
//     }

//  }
//  export default DeleteProd;
    
