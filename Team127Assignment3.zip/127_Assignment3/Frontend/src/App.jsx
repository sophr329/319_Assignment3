import './App.css';
import { useState, useEffect } from "react";
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import { Link } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.css"; 
import Products from './Products';
import CreateProd from './CreateProd';
import UpdateProd from './UpdateProd';
import GetProd from './GetOneProd';
import DeleteProd from './Delete' 


const App = () => {
  return (
      <div>
        <BrowserRouter>
            <Routes>
              <Route path='/' element={<Products/>}></Route>
              <Route path='/getProducts/:id' element={<UpdateProd/>}></Route>
              <Route path='/create' element={<CreateProd/>}></Route>
              <Route path='/update/:id' element={<UpdateProd/>}></Route>
            </Routes>
          </BrowserRouter> 
      </div>
    );

}

export default App;
