import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import axios from "axios";

const Products = () => {
  const [prods, setProds] = useState([
    {
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      rating: "",
    },
  ]);

  useEffect(() => {
    axios
      .get("http://localhost:8082/getProducts")
      .then((result) => {
        setProds(result.data);
        console.log("I am in use effect with not hook");
      })
      .catch((err) => console.log(err));
    }, []);
    


  const handleDelete = async (id) => {
    console.log(id);
    console.log("Product to delete :", id);
    axios
      .delete("http://localhost:8082/deleteProd/" + id, {})
      .then((data) => {
        console.log("Delete a product completed : ", id);
        console.log(data);
        // reload products from the local products array
        const newProducts = prods.filter((product) => product.id !== id);
        setProds(newProducts);
        // show alert
        if (data) {
          const key = Object.keys(data);
          const value = Object.values(data);
          console.log("This is the response from backend",data.message);
          alert(key + value);
        }
      })
      .catch((error) => {
        console.error("Error deleting item :", error);
        alert("Error deleting product: " + error.message); // Display alert if there's an error
      });
  };

  const ShowProducts = () => {
    return (
      <div className="container mt-3">
        <div className="row">
          {prods.map((product) => (
            <div
              key={product.id}
              className="col-12 col-sm-6 col-md-4 col-lg-3 mb-4"
            >
              <div className="card">
                <img
                  src={product.image}
                  className="card-img-top"
                  alt={product.title}
                  style={{ objectFit: "cover", height: "200px" }}
                />
                <div className="card-body">
                  <h2 className="card-title">
                    {product.id}: {product.title}, ${product.price}
                  </h2>
                  <h5 className="card-text">Category: {product.category}</h5>
                  <h5 className="card-text">Rating: {product.rating.rate}</h5>
                  <h5 className="card-text">Count: {product.rating.count}</h5>
                  <Link
                    to={`/update/${product.id}`}
                    className="btn btn-success"
                  >
                    Edit
                  </Link>{" "}
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="btn btn-danger"
                  >
                    Delete
                  </button>
                  {/* <button id="edit" >Edit</button> <button id='delete'>Delete</button> */}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // {(e) => handleDelete(product.id)}
  return (
    <div>
      <Link to="/create" className="btn btn-dark">
        Add +
      </Link>
      <ShowProducts />
    </div>
  );
};

export default Products;

// useEffect(() => {
//   getAllProducts();
//   }, []);
//   function getAllProducts() {
//     fetch("http://localhost:8082/getProducts")
//     .then((response) => response.json())
//     .then((data) => {
//     console.log("Show Catalog of Products :");
//     console.log(data);
//     setProduct(data.data);
//     });
//   }

// function getOneProduct(id) {
//   console.log(id);
//   if (id >= 1) {
//     fetch("http://localhost:8082/getProducts/" + id)
//       .then((response) => response.json())
//       .then((data) => {
//       console.log("Show one product :", id);
//       console.log(data);
//       setOneProduct(data);
//   });
//   if (false === viewer2)
//   setViewer2(true);
//   } else {
//   console.log("Wrong number of Product id.");
//   }
//   }
