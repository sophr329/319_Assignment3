import { useState, useEffect } from "react";
import {Link, useNavigate } from 'react-router-dom';
import React from "react";
import axios from 'axios'

 function CreateProd (){
    const [id,setId] = useState(0)
    const [title,setTitle] = useState()
    const [description,setDescription] = useState()
    const [category,setCategory] = useState()
    const [price,setPrice] = useState()
    const [image,setImage] = useState()
    const [rate,setRate] = useState(0)
    const [count,setCount] = useState(0)
    const navigate = useNavigate()
    

    const Submit = (e) => {
        e.preventDefault();
        console.log(id,title,description,category,price,image,rate,count);
        axios.post("http://localhost:8082/create", {id,title,price,description,category,image,rate,count})
        .then(result => {
            console.log(result)
            navigate('/')
        })
        .catch(err => console.log(err))
            .then(data => {
                console.log(data);
                alert("Item added successfully!");
            })
            .catch(error => {
                console.error('Error adding item:', error);
                alert('Error adding product:'+error.message); // Display alert if there's an error
            });
    }

    return(
        <div>
        <Link to="/" className="btn btn-dark">View All</Link>
        <div className="d-flex vh-100 bg-white justify-content-center align-items-center">
            
            <div className="w-70 bg-secondary rounded p-3">
                <form onSubmit={Submit}>
                    <h2>Add Product</h2>
                    <div className="mb-2">
                        <label htmlFor="">Id</label>
                        <input type="number" placeholder="Enter Id" className="form-control"
                        onChange={(e => setId(e.target.value))} required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Title</label>
                        <input type="text" placeholder="Enter Title" className="form-control"
                        onChange={(e => setTitle(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Price</label>
                        <input type="number"step="any" placeholder="Enter Price" className="form-control"
                        onChange={(e => setPrice(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Description</label>
                        <input type="text" placeholder="Enter Description" className="form-control"
                       onChange={(e => setDescription(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Categoty</label>
                        <input type="text" placeholder="Enter Categoty" className="form-control"
                        onChange={(e => setCategory(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Image</label>
                        <input type="text" placeholder="Enter image url" className="form-control"
                        onChange={(e => setImage(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Rating</label>
                        <input type="number" step="any" placeholder="Enter Rating" className="form-control"
                        onChange={(e => setRate(e.target.value))}required/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Count</label>
                        <input type="number" step="any" placeholder="Enter Rating" className="form-control"
                        onChange={(e => setCount(e.target.value))}required/>
                    </div>
                    <button className="btn btn-dark">Submit</button>
                </form>

            </div>
        </div>
        </div>
    )
}

 export default CreateProd