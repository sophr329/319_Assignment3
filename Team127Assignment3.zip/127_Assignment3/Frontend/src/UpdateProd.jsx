import React, {useState, useEffect} from "react";
import { useParams, useNavigate, Link} from "react-router-dom";
import axios from "axios";

 function UpdateProd (){
    const {id} = useParams()
    const [name,setName] = useState()
    const [title,setTitle] = useState()
    const [description,setDescription] = useState()
    const [category,setCategory] = useState()
    const [price,setPrice] = useState()
    const [image,setImage] = useState()
    const [rate,setRate] = useState()
    const [count,setCount] = useState()
    const navigate = useNavigate()

    useEffect(()=>{
        console.log('in update useEffect')
        axios.get("http://localhost:8082/getProducts/"+id)
        .then(result => {
            console.log(result)
            setName(result.data.id)
            setTitle(result.data.title)
            setDescription(result.data.description)
            setCategory(result.data.category)
            setPrice(result.data.price)
            setImage(result.data.image)
            setRate(result.data.rating.rate)
            setCount(result.data.rating.count)

        })
        .catch(err => console.log(err))
      },[])


      const Update = async(e) =>{
        console.log("in update onSubmit")
        e.preventDefault();
        console.log(name,title,description,category,price,image,rate,count);
        await axios.put("http://localhost:8082/update/"+id, {name,title,price,description,category,image,rate,count})
        .then(result => {
            console.log(result)
            navigate('/')
        })
        .catch(err => console.log(err))
    }

    return(
        <div>
            <Link to="/" className="btn btn-dark">View All</Link>
        
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-70 bg-white rounded p-3">
                <form onSubmit={Update}>
                <h2>Update Product</h2>
                    <div className="mb-2">
                        <label htmlFor="">Id</label>
                        <input type="text" placeholder="Enter Id" className="form-control"
                        defaultValue={name} onChange={(e) => setName(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Title</label>
                        <input type="text" placeholder="Enter Title" className="form-control"
                        defaultValue={title} onChange={(e) => setTitle(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Price</label>
                        <input type="text" placeholder="Enter Price" className="form-control"
                        defaultValue={price} onChange={(e) => setPrice(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Description</label>
                        <input type="text" placeholder="Enter Description" className="form-control"
                        defaultValue={description} onChange={(e) => setDescription(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Categoty</label>
                        <input type="text" placeholder="Enter Categoty" className="form-control"
                        defaultValue={category} onChange={(e) => setCategory(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Image</label>
                        <input type="text" placeholder="Enter image url" className="form-control"
                        defaultValue={image} onChange={(e) => setImage(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Rating</label>
                        <input type="text" placeholder="Enter Rating" className="form-control"
                        defaultValue={rate} onChange={(e) => setRate(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Count</label>
                        <input type="text" placeholder="Enter Rating" className="form-control"
                        defaultValue={count} onChange={(e) => setCount(e.target.value)}/>
                    </div>
                    <button className="btn btn-dark">Update</button>
                </form>

            </div>
        </div>
        </div>
    )
}

 export default UpdateProd