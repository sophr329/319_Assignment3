import React, {useState, useEffect} from "react";
import { useParams, useNavigate, Link} from "react-router-dom";
import axios from "axios";

 function GetProd (){
    //const {id} = useParams()
    //const [id,setName] = useState()
    const [title,setTitle] = useState()
    const [description,setDescription] = useState()
    const [category,setCategory] = useState()
    const [price,setPrice] = useState()
    const [image,setImage] = useState()
    const [rating,setRating] = useState()
    const [count,setCount] = useState()
    //const navigate = useNavigate()
    const [oneProduct, setOneProduct] = useState([]);
    const navigate = useNavigate();
    const [id, setId] = useState("")

    useEffect(()=>{
        fetch("http://localhost:8082/getProducts/"+id)
        .then(result => {
            console.log(result)
            setId(result.data.id)
            setTitle(result.data.title)
            setDescription(result.data.description)
            setCategory(result.data.category)
            setPrice(result.data.price)
            setImage(result.data.image)
            setRating(result.data.rating.rate)
            setCount(result.data.rating.count)

        })
        .catch(err => console.log(err))
        if (id) {
            fetch(`http://127.0.0.1:3000/getProducts/${id}`)
            .then((response) => response.json())
            .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
            });
        }
      },[id])

      const Update = (e) =>{
        console.log("in update")
        e.preventDefault();
        console.log(id,title,description,category,price,image,rating,count);
        axios.put("http://localhost:8082/update/"+id, {id,title,price,description,category,image,rating,count})
        .then(result => {
            console.log(result)
            navigate('/')
        })
        .catch(err => console.log(err))
    }


    return(
        <div>
            <Link to="/" className="btn btn-dark">View All</Link>
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-70 bg-white rounded p-3">
                <form onSubmit={Update}>
                <h2>Update Product</h2>
                    <div className="mb-2">
                        <label htmlFor="">Id</label>
                        <input type="text" placeholder="Enter Id" className="form-control"
                        value={id} onChange={(e) => setId(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Title</label>
                        <input type="text" placeholder="Enter Title" className="form-control"
                        value={title} onChange={(e) => setTitle(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Price</label>
                        <input type="text" placeholder="Enter Price" className="form-control"
                        value={price} onChange={(e) => setPrice(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Description</label>
                        <input type="text" placeholder="Enter Description" className="form-control"
                        value={description} onChange={(e) => setDescription(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Categoty</label>
                        <input type="text" placeholder="Enter Categoty" className="form-control"
                        value={category} onChange={(e) => setCategory(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Image</label>
                        <input type="text" placeholder="Enter image url" className="form-control"
                        value={image} onChange={(e) => setImage(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Rating</label>
                        <input type="text" placeholder="Enter Rating" className="form-control"
                        value={rating} onChange={(e) => setRating(e.target.value)}/>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="">Count</label>
                        <input type="text" placeholder="Enter Rating" className="form-control"
                        value={count} onChange={(e) => setCount(e.target.value)}/>
                    </div>
                    <button className="btn btn-dark">Update</button>
                </form>

            </div>
        </div>
        </div>
    )
}

export default GetProd