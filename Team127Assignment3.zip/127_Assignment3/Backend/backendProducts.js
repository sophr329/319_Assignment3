
var express = require("express");
var cors = require("cors");
var app = express();
var bodyParser = require("body-parser");
const ProductModel = require('./models/Products');
const { default: mongoose } = require("mongoose");

app.use(cors());
app.use(bodyParser.json());

const port = "8082";
const host = "localhost";

const { MongoClient } = require("mongodb");

const url = "mongodb://127.0.0.1:27017/reactdata";
const dbName = "reactdata";
const client = new MongoClient(url);
const db = client.db(dbName);

//get all
app.get("/getProducts", async (req, res) => {     
    await client.connect();
    console.log("Node connected successfully to GET MongoDB");
    const query = {};
    const results = await db
    .collection("fakestore_catalog")
    .find(query)
    .limit(100)
    .toArray();
    console.log(results);
    res.status(200);
    res.send(results);
});

//get by id
app.get("/getProducts/:id", async (req, res) => {
    const prodId = Number(req.params.id);
    await client.connect();
    console.log("Node connected successfully to GET-id MongoDB");
    const query = {"id": prodId };

    const results = await db.collection("fakestore_catalog")
    .findOne(query);
    
    console.log("Results :", results);
    if (!results) res.send("Not Found").status(404);
    else res.send(results).status(200);
});

//add new product
app.post("/create", async (req, res) => {
    try{
        await client.connect();
        
        const newProd = {
            "id": Number(req.body.id),
            "title": req.body.title,
            "price": Number(req.body.price),
            "description": req.body.description,
            "category": req.body.category,
            "image": req.body.image,
            "rating": {
                "rate": Number(req.body.rate),
                "count": Number(req.body.count)
            }
        };

        console.log(newProd);
        const results = await db
        .collection("fakestore_catalog")
        .insertOne(newProd);
        res.status(200);
        res.send(results)
    }
    catch(error){
        console.error("An error occurred:", error);
        res.status(500).send({error:"An internal server error occurred"})
    }
});

//put by id
app.put("/update/:id", async (req, res) => {
    const id = Number(req.params.id);
    const query = { id: id };

    await client.connect();
    console.log("Product to Update :",id);

    // Data for updating the document, typically comes from the request body
    console.log(req.body);

    const updateData = {
        $set:{
            "title": req.body.title,
            "price": req.body.price,
            "description": req.body.description,
            "category":req.body.category,
            "image": req.body.image,
            "rating": {
                "rate": req.body.rate,
                "count": req.body.count
            } 
        }
    };
    // Add options if needed, for example { upsert: true } to create a document if it doesn't exist
    const prodUpdated = await db.collection("fakestore_catalog").findOne(query);
    console.log("I found in Update :",prodUpdated);
    if (prodUpdated == null) {
        return res.status(409).send({ message: 'ID to Update does not exists.' });
    }
    const options = { };
    const results = await db.collection("fakestore_catalog").updateOne(query, updateData, options);
    if (results.matchedCount === 0) {
        return res.status(404).send({ message: 'Products not found in Update' });
    }
    return res.status(200).send({ message: 'Products Updated.' });

});

//delete by id
app.delete("/deleteProd/:id", async (req, res) => {
    try {
        const id = Number(req.params.id);
        console.log("Product to delete :",id);

        await client.connect();

        const query = { id: id };

        // delete
        const prodDeleted = await db.collection("fakestore_catalog").findOne(query);
        console.log("I found in Delete:",prodDeleted);
        if (prodDeleted === null) {
            return res.status(409).send({ message: 'ID to delete does not exists.' });
        }
        // everything is correct
        const results = await db.collection("fakestore_catalog").deleteOne(query);
        res.status(200).send({ message: 'Product deleted successfully' });
    }
    catch (error){
        console.error("Error deleting product:", error);
        res.status(500).send({ message: 'Internal Server Error' });
    }

});


app.listen(port, () => {
    console.log("App listening at http://%s:%s", host, port);
    });


